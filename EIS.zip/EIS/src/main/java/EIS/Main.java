package EIS;

import java.io.IOException;
import javax.swing.JFrame;
 
 
 public class Main 
 {
  public static Query_Panel myShape;

  public static void main(String[] args) throws IOException
   {	  
	     myShape=new  Query_Panel();    
	    JFrame application=new JFrame("EUR to Currency ratio");
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		application.add(myShape);
		application.setSize(500,800);
		application.setResizable(false);
		application.setVisible(true);	
   }
 }
