package EIS;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.io.IOException;
/*
 This class defines the layout of the visual panel and the related methods.
*/

public class Query_Panel extends JPanel 
{
/*The layout is devided into three parts.
  The start date , end date and the currency combo boxes at the upper part.
  The the part of the table that displays the output of the requested information at the middle.
  The lower part is the request button	
*/	
	//Start date Jpanel
	private final 	JPanel     Start_dateJPanel    = new JPanel();
	//End date Jpanel
	private final 	JPanel     End_dateJPanel      = new JPanel();
	//Currency Jpanel
	private final 	JPanel     Currency_JPanel     = new JPanel();
	//All panels will  be attached to this panel.
	public 	final 	JPanel 	   All_panel		   = new JPanel(new GridLayout(3,1));
	public 	final 	JPanel 	   info_panel		   = new JPanel();
	
	private final   JLabel Start_DayJLabel=new JLabel("Start day");
	//JComboBoxes for choosing start day month year	
	private final   JComboBox<Integer> Start_DayJComboBox;   
	private final   JComboBox<Integer> Start_MonthJComboBox; 
	private final   JComboBox<Integer> Start_YearJComboBox; 
	
	private final   JLabel End_DayJLabel=new JLabel("End day ");
	//JComboBoxes for choosing end day month year
	private final   JComboBox<Integer> End_DayJComboBox;   
	private final   JComboBox<Integer> End_MonthJComboBox; 
	private final   JComboBox<Integer> End_YearJComboBox; 
	
	private final   JLabel Currency_JLabel=new JLabel("Currency");
	//JComboBoxes for currency
	private final   JComboBox<String>  Currency; 
	//Information for user
	private final   JTextArea  information;  
	private final   JLabel Ratio_JLabel=new JLabel("Variation");
	private final   JTextArea  Ratio; 
	private final   JLabel Ration_percnt_JLabel=new JLabel("Variation %");
	private final   JTextArea  Ratio_percnt;
	
	
	//JButton and JPanel for the button for information request
	private final 	JPanel       buttonJPanel   = new JPanel();
	private 	JButton          buttons		= new JButton();
	
	//JTable to display the output
	private  static JTable jt=new JTable();
	
	//Initialization values
	private int  start_dd=1;
	private int  start_mm=1;
	private int  start_yy=2017;
	private int  end_dd=1;
	private int  end_mm=1;
	private int  end_yy=2017;
	private String  curr="AUD";
	private Date start;
	private Date end;
	String out;
	
	public Bank_connect connect=new Bank_connect();
	Constant cons=new Constant();
	
	private String[] column={"Date","Ratio"//,"Change","Change %"
			};  
	public static Data_trans transforms=new Data_trans();
	
	public Query_Panel()
	{
	
	//Start date day combo box initialization.	
	Start_DayJComboBox = new JComboBox<Integer>(cons.get_days());
	Start_DayJComboBox.setMaximumRowCount(5);
	
	//Start date month combo box initialization.	
	Start_MonthJComboBox = new JComboBox<Integer>(cons.get_months());
	Start_MonthJComboBox.setMaximumRowCount(5);
	
	//Start date year combo box initialization.		
	Start_YearJComboBox = new JComboBox<Integer>(cons.get_years());
	Start_YearJComboBox.setMaximumRowCount(5);
	
	//end date day combo box initialization.	
	End_DayJComboBox = new JComboBox<Integer>(cons.get_days());
	End_DayJComboBox.setMaximumRowCount(5);
	
	//End date month combo box initialization.	
	End_MonthJComboBox = new JComboBox<Integer>(cons.get_months());
	End_MonthJComboBox.setMaximumRowCount(5);
	
	//End date year combo box initialization.	
	End_YearJComboBox = new JComboBox<Integer>(cons.get_years());
	End_YearJComboBox.setMaximumRowCount(5);
	
	//Currency combo box initialization.	
	Currency = new JComboBox<String>(cons.get_currency());
	Currency.setMaximumRowCount(5);
	
	//Information for the user
	information=new JTextArea(5,40);
	information.setText("Information for the user");
	
	
	Ratio=new JTextArea(2,5);
	Ratio_percnt=new JTextArea(2,5);
	
	//Forming start date panel	
	Start_dateJPanel.add(Start_DayJLabel );
	Start_dateJPanel.add(Start_DayJComboBox );
	Start_dateJPanel.add(Start_MonthJComboBox );
	Start_dateJPanel.add(Start_YearJComboBox );
	//Forming end date panel	
	End_dateJPanel.add(End_DayJLabel );
	End_dateJPanel.add(End_DayJComboBox );
	End_dateJPanel.add(End_MonthJComboBox );
	End_dateJPanel.add(End_YearJComboBox );
	//Forming currency panel
	
	Currency_JPanel.add(Currency_JLabel);
	Currency_JPanel.add(Currency);	
	
	//Initialize JTable	
	int numRows = 3 ;
	DefaultTableModel model = new DefaultTableModel(numRows, column.length) ;
	model.setColumnIdentifiers(column);	
	jt = new JTable(model);
	jt.setBounds(20,20,200,200);          
	JScrollPane sp=new JScrollPane(jt); 	
	
	//Initialize jbutton
	this.buttons = new JButton("Get Data");	
	buttonJPanel.add(buttons);
	
	//form final panel
	All_panel.add(Start_dateJPanel);	
	All_panel.add(End_dateJPanel);
	All_panel.add(Currency_JPanel);	
	this.add(All_panel,BorderLayout.NORTH);	
	this.add(sp,BorderLayout.CENTER);
	
	info_panel.add(Ratio_JLabel);
	info_panel.add(Ratio);
	info_panel.add(Ration_percnt_JLabel);
	info_panel.add(Ratio_percnt);
	this.add(info_panel,BorderLayout.CENTER);
	this.add(information,BorderLayout.CENTER);
	this.add(buttonJPanel,BorderLayout.SOUTH);
	
			
//Action listeners for all the components of the panel 
//Get button	
	buttons.addActionListener(
			 new ActionListener() // anonymous inner class
			 {
			 @Override
			 public void actionPerformed(ActionEvent event)
			 {   //Get the start and the end date of the requested period
				 information.setText("");
				 Ratio.setText("");
				 Ratio_percnt.setText("");
				 start=new Date(start_dd,start_mm,start_yy);
				 end=new Date(end_dd,end_mm,end_yy);				 
				 String str_date=start.toString();				 
				 String end_date=end.toString();
				 
				 //If the start date exceeds the end date continue requesting until the above requirement is fulfilled
				 int continueloop=1;
				 int temp;
				 do
				 {   
					try 
					 {
						temp = start.compareTo(end);
						if(temp>0){throw new IllegalArgumentException();}						
					    continueloop=-1;
					 }
				     catch (IllegalArgumentException illegalArgumentException) 
					 {
				    	out="\nThe start date must be before the end date\nplease provide valid dates";
				    	information.setText(out);
				    	start=new Date();
				    	end=new Date();	
				    	return;
					 }
				 }
				 while(continueloop>0);
				 
				 //Form the required url address with all the information.
				 String curren=curr;
				 String url=connect.get_url(str_date,end_date,curren);				 
				 //if the number of the current rows of the table is now enough to display all the information - increase it.
				 if (end.day_difference(start)>=jt.getRowCount())
					 {							 model.setRowCount(end.day_difference(start)+2);							 }
				 // Update table with the information
				 try {
	                 model.fireTableDataChanged();
	                 String[][] df=connect.get_information(url); 
	                 String out1=update_table(df); 	
	                 information.setText(out1); 
					 String[] ratio_a=transforms.calculate_ratio(df);
		             Ratio.setText(ratio_a[0]);
		             Ratio_percnt.setText(ratio_a[1]);
	          		} 
				 	catch (IOException e) 
				 	{e.printStackTrace();}
				 
				 	
			 }
			 }
			 );
//All the below action listeners 	
//update the string variables for the start and the end dates and the currency variable string.	
	
//Start_Day JComboBox
	Start_DayJComboBox.addItemListener(
			new ItemListener() // anonymous inner class
			{
			// handle JComboBox event
			@Override
			public void itemStateChanged(ItemEvent event)
			{
			// determine whether item selected
			if (event.getStateChange() == ItemEvent.SELECTED)
				
			start_dd=(int) Start_DayJComboBox.getSelectedItem();
			}
			} 
			); 
//Start_Day Month JComboBox	
	Start_MonthJComboBox.addItemListener(
			new ItemListener() // anonymous inner class
			{
			// handle JComboBox event
			@Override
			public void itemStateChanged(ItemEvent event)
			{
			// determine whether item selected
			if (event.getStateChange() == ItemEvent.SELECTED)
			start_mm=(int) Start_MonthJComboBox.getSelectedItem();
			
			//Change the drop list on the JCombobox as dependent on the month
				if(start_mm == 4 ||start_mm == 6 ||start_mm == 9 ||start_mm == 11 ) 
				{   start_dd=1;
					Start_DayJComboBox.setModel(new DefaultComboBoxModel<Integer>(cons.get_days1()));
				}
				if(start_mm == 1 ||start_mm == 3 ||start_mm == 5 ||start_mm == 7 ||start_mm == 8 ||start_mm == 10 ||start_mm == 12) 
				{   start_dd=1;
					Start_DayJComboBox.setModel(new DefaultComboBoxModel<Integer>(cons.get_days()));
				}				
				if(start_mm == 2) 
				{   start_dd=1;
					Start_DayJComboBox.setModel(new DefaultComboBoxModel<Integer>(cons.get_days2()));
				}
			}
			} 
			); 
//Start_Day Year JComboBox		
	Start_YearJComboBox.addItemListener(
			new ItemListener() // anonymous inner class
			{
			// handle JComboBox event
			@Override
			public void itemStateChanged(ItemEvent event)
			{
			// determine whether item selected
			if (event.getStateChange() == ItemEvent.SELECTED)
			start_yy=(int) Start_YearJComboBox.getSelectedItem();
			}
			} 
			); 
//End_Day day JComboBox		
	End_DayJComboBox.addItemListener(
			new ItemListener() // anonymous inner class
			{
				
			// handle JComboBox event
			@Override
			public void itemStateChanged(ItemEvent event)
			{
			end_dd=1;
			// determine whether item selected
			if (event.getStateChange() == ItemEvent.SELECTED)
			end_dd=(int) End_DayJComboBox.getSelectedItem();			
			}
			} // end anonymous inner class
			); // end call
//End_Day month JComboBox		
	End_MonthJComboBox.addItemListener(
			new ItemListener() // anonymous inner class
			{
			// handle JComboBox event
			@Override
			public void itemStateChanged(ItemEvent event)
			{
			// determine whether item selected
			if (event.getStateChange() == ItemEvent.SELECTED)
			end_mm=(int) End_MonthJComboBox.getSelectedItem();
			
			//Change the drop list (30 , 31, 29 days) on the JCombobox as dependent on the month
				if(end_mm == 4 ||end_mm == 6 ||end_mm == 9 ||end_mm == 11 ) 
				{   end_dd=1;
					End_DayJComboBox.setModel(new DefaultComboBoxModel<Integer>(cons.get_days1()));
				}
				if(end_mm == 1 ||end_mm == 3 ||end_mm == 5 ||end_mm == 7 ||end_mm == 8 ||end_mm == 10 ||end_mm == 12) 
				{   end_dd=1;
					End_DayJComboBox.setModel(new DefaultComboBoxModel<Integer>(cons.get_days()));
				}	
				if(end_mm == 2) 
				{   end_dd=1;
					End_DayJComboBox.setModel(new DefaultComboBoxModel<Integer>(cons.get_days2()));
				}
			}
			} 
			); 
//End_Day Year JComboBox		
	End_YearJComboBox.addItemListener(
			new ItemListener() // anonymous inner class
			{
			// handle JComboBox event
			@Override
			public void itemStateChanged(ItemEvent event)
			{
			// determine whether item selected
			if (event.getStateChange() == ItemEvent.SELECTED)
			end_yy=(int) End_YearJComboBox.getSelectedItem();
			}
			} 
			); 

	
	Currency.addItemListener(
			new ItemListener() // anonymous inner class
			{
			// handle JComboBox event
			@Override
			public void itemStateChanged(ItemEvent event)
			{
			// determine whether item selected
			if (event.getStateChange() == ItemEvent.SELECTED)
			curr=(String) Currency.getSelectedItem();			
			}
			} 
			); 
	}
	
//method for updating the information in the table		 
	 private String update_table(String[][] table) 
	 {  String out="";
	 
	 //clear the table 
	 for (int i = 0; i < jt.getRowCount(); i++)
	 {
	      for(int j = 0; j < jt.getColumnCount(); j++)
	      {
	          jt.setValueAt("", i, j);
	      }
	   }
	 
	//update the table with new content 
		 for (int i=0;i<table.length;i++)
		 {   					 
			 for(int j=0;j<table[i].length;j++)
			 {	
				 if ((table[0][0]==null)) 
				 {
				  out="The list is empty.\nThe chosen dates might be weekend \nor the information is not available for this period";
				  break;
				  }
				 
				 else if((table[i][j]!=null))
				{	jt.getModel().setValueAt(table[i][j], i, j);}
				
			 }			 
		 }
		 start=new Date();
	     end=new Date();	
		 return out;
	 }
	 
	 
	
}	

