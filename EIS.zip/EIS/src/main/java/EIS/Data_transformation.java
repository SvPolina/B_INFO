package EIS;

public interface Data_transformation {
	
	public  String[][] text_to_table(String data) ;
	public  String[][] flip_columns(String[][] table);
	public  String [][] calculate_ratio_each(String[][] table);
	public String[] calculate_ratio(String[][] table);

}
