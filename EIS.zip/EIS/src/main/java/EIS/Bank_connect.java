package EIS;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/*This class contains all the methods needed to enquire the required information from the bank.*/	

public class Bank_connect implements Bank_information{
	
    public static Data_trans transform=new Data_trans();
    
// return the url string based on the dates and the currency information
@Override
	public String get_url(String str_date,String end_date,String curren)
	{	
		String url="https://www.lb.lt/lt/currency/exportlist/?csv=1&currency="+curren+"&ff=1&class=Eu&type=day&date_from_day="+str_date+"&date_to_day="+end_date;			
		return url;
	}	
	
// Get information from required url	
@Override
	public String[][] get_information( String l) throws IOException
	{
		URL link = new URL(l);     
        InputStream in = new BufferedInputStream(link.openStream());
        String[][] result = getStringFromInputStream(in);		
		return result;
	}
// Process the information from the stream and return it in form of table
@Override
	public String[][] getStringFromInputStream(InputStream is) 
	{
			BufferedReader br = null;
			StringBuilder sb = new StringBuilder();
			String[][] tabl=null;
			String line;
			try {
				br = new BufferedReader(new InputStreamReader(is));
				while ((line = br.readLine()) != null) 
				{
					sb.append(line);
					sb.append("\n");
				}				
		
				tabl=transform.flip_columns(transform.text_to_table(sb.toString()));

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}			
			return tabl;
	}

}
