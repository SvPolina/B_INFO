package EIS;
//Class that contains all the methods to transform the information received from the
//requested url.

public class Data_trans implements Data_transformation {

//Tokenize the String of input data	
//and output it as a table	
@Override
public  String[][] text_to_table(String data) 
	 {
		 String[] tokens = data.split("\\n+");	
		 String [][] tab =new String[tokens.length][2];
		 
		 for (int i=1;i<tokens.length;i++)
		 {   	
			 String[] temp=tokens[i].split(";\"");	
			 for(int j=temp.length-1;j>1;j--)
			 {			
			 temp[j] = temp[j].substring(0, temp[j].length()- 1);
			 tab[i-1][j-2]=temp[j];
			 }	
	     }			
		 return tab;
	 }

//Exchange the date and the ratio columns	 
@Override
 public  String[][] flip_columns(String[][] table) 
	 {
		 String[][] temp=new String[table.length][2];
		 for (int i=0;i<table.length;i++)
		 { temp[i][0]=table[i][1];
		   temp[i][1]=table[i][0]; 
		 }
		 return temp;
	 }
 
//Calculate the change of the ratio during the requested period between each two days
@Override
public  String [][] calculate_ratio_each(String[][] table)
	 { 
		String[][] temp=new String[table.length][4];
		for (int i=0;i<table.length-1;i++)
	 	{ 
		if((table[i+1][1]!=null))
			{
		  String first = table[i+1][1].replace(",", ".");		 
		  String second= table[i][1].replace(",", ".");		  
		  Float first_f=Float.valueOf(first);
		  Float second_f=Float.valueOf(second);	 		  
	   	  temp[i][2]=Float.toString((first_f-second_f));	 	  
	 	  temp[i][3]=Float.toString(((first_f-second_f)/first_f)*100);	
	     
			}
		}
		for (int i=0;i<table.length;i++)
		 {   					 
			 for(int j=0;j<table[i].length-2;j++)
			 {
				 temp[i][j]=table[i][j];
			 }
		}
		return temp; 
	 }

//Calculate the change of the currency ratio for the requested period 
@Override
public String[] calculate_ratio(String[][] table)
{   
	String resultf[]=new String[2];
	String temp1=table[0][1];
	String temp2="";
	for (int i=0;i<table.length;i++)
	{
			if(table[i][1]!=null)
		{
			temp2=table[i][1];
			
			  String first = temp1.replace(",", ".");		 
			  String second= temp2.replace(",", ".");		  
			  Float first_f=Float.valueOf(first);
			  Float second_f=Float.valueOf(second);	
			  Float result=first_f-second_f; 
			  Float result_per=result/first_f;
			 
		      resultf[0] = String.format("%.5f", result);
		      resultf[1] = String.format("%.5f", result_per);			
		}
	}
   //
	  return resultf;	
}

}
