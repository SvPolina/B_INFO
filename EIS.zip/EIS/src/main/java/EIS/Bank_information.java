package EIS;
import java.io.IOException;
import java.io.InputStream;

public interface Bank_information {
	
	public String get_url(String str_date,String end_date,String curren);
	public String[][] get_information( String l) throws IOException;
	public String[][] getStringFromInputStream(InputStream is);
}
