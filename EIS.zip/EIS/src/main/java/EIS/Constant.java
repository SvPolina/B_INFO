package EIS;
//Class for all the constant variables used by the application.

public class Constant 
{       //3 Variants of days in month
		private Integer[] days =	{1, 2,3, 4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31};
		private Integer[] days_1 =	{1, 2,3, 4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};		
		private Integer[] days_2 =	{1, 2,3, 4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28};	
		
		//months list
		private Integer[] months =	{1,2,3,4,5,6,7,8,9,10,11,12};	
		
		//years list
		private Integer[] years =	{2017,2018,2019,2020};		
		private String[]  currency ={   "AUD",//"AED","AFN","ALL","ARS","AMD",
										"BGN","BRL",//"BHD","BYR","BYN","BDT","BRL","BOB","BAM",
										"CAD","CHF","CNY","CZK",//"CLP","COP",
										"DKK",//"DZD","DJF",
										"GBP",//"EGP","ETB","GHS","GEL","GNF",
										"HKD","HRK","HUF",//"HRK",
										"IDR","ILS","INR","ISK",//"IQD","IRR",
										"JPY",//"JOD",
										"KRW",//"KES","KGS","KZT","KWD",
										//"LBP","LYD","LKR",
										"MXN","MYR",//"MAD","MGA","MDL","MKD","MXN","MNT","MUR","MZN",
										"NOK","NZD",//"NDK","NGN",
										"PHP","PLN",//"PAB","PEN","PKR",
										//"QAR",
										"RON","RUB",//"RSD",
										"SEK","SGD",//"SAR","SYP"
										"THB","TRY",//"TJS","TWD","TZS","TND","TMT",
										"USD",//"UAH","UYU","UZS",
										//"VEF","VND",
										//"XOF","XAF","YER",
										"ZAR"};

		//stter and getter methods
		public void set_days(Integer[] days ){this.days=days;}
		public void set_days1(Integer[] days_1 ){this.days_1=days_1;}
		public void set_days2(Integer[] days_2 ){this.days_2=days_2;}
		public void set_months(Integer[] months){this.months=months;}
		public void set_years(Integer[] years){this.years=years;}
		public void  set_currency(String[] currency){this.currency=currency;}
		
		public Integer[] get_days(){return days;}
		public Integer[] get_days1(){return days_1;}
		public Integer[] get_days2(){return days_2;}
		
		public Integer[] get_months(){return months;}
		public Integer[] get_years(){return years;}
		public String[] get_currency(){return currency;}
}
