package EIS;
//Class that contains all the methods for date manipulation

public class Date implements Comparable<Date> {
	
	private int year; 
	private int month; 
	private int day;
	
	public Date()
	{this(1,1,2017);}
	
	public Date(int day, int month, int year)
	{	 this.year = year;
		 this.month = month;
		 this.day = day;
	}	
		
	public Date(Date date)
	{
	this(date.getDay(), date.getMonth(),date.getYear() );
	}
	
	public void setDate(int day, int month, int year)
	 {
		 		 this.year = year;
				 this.month = month;
				 this.day = day;
     }
	
//getter and setter methods	
	public void setYear(int year)
	 {	 	 this.year = year;	 }	
	
	 public void setMonth(int month)
	 {	 this.month = month;	 }	
	
	 public void setDay(int day)
	 {	 this.day = day;	 }
	
	public int getYear()
	 {	 return year;	 }	
	 
	 public int getMonth()
	 {	 return month;	 }
	
	public int getDay()
	 {	 return day;	 }
	

//check if dates are equal
	@Override
	public boolean equals(Object date1)
	{
	Date date2=(Date)date1;
	if (this.getYear()==date2.getYear()&&this.getMonth()==date2.getMonth()&&this.getDay()==date2.getDay()){return true;}	
	else return false;
	}

//calculate approximated difference between two dates (all the month assumed to be 31 days).	
	 public int day_difference(Date date2)
	 {   
		 
	 	 int years_tot=this.getYear()-date2.getYear();
	 	 int days=0;
	 	 
	 	 days=12*years_tot*31+this.getMonth()*31+this.getDay()-(date2.getMonth()*31+date2.getDay());
	 	 return days;
	 }
	 
	public Date get_prev_date(int num)
	{
		int days=12*(this.getYear()-2017)*31+this.getMonth()*31+this.getDay()-num;
		int year=(days/12/31);
		int month=(days-12*31)/31;
		int day=(days-(year*12+month)*31);
		Date return_date=new Date(day,month,(year+2017));
		return return_date;
	}

//compare two dates and define which one is later/earlier.
	 @Override
	 public int compareTo(Date date2) 
	 {
		 if (this.getYear()<date2.getYear())
		 { return -1;}
		 else if ((this.getYear()==date2.getYear())&&(this.getMonth()<date2.getMonth()))
		 { return -1;}
		 else if ((this.getYear()==date2.getYear())&&(this.getMonth()==date2.getMonth())&&(this.getDay()<date2.getDay()))
		 { return -1;}
		 else  if (this.equals(date2)==true){return 0;}
		       else {return 1;}
	 }
//return string representation of the date object	 
	 @Override
	 public String toString()
	 {
		String day;
		String month;
		String year;
		
		if(this.getDay()<10)
		{
			day="0"+Integer.toString(this.getDay());
		} 
		else day=Integer.toString(this.getDay());
		
		if(this.getMonth()<10)
		{
			month="0"+Integer.toString(this.getMonth());
		} 
		else month=Integer.toString(this.getMonth());
		
		year=Integer.toString(this.getYear());
		
		return year+"-"+month+"-"+day;
	 }

	
	
}

