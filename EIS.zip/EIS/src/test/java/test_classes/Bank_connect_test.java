package test_classes;

import static org.junit.Assert.*;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;


import EIS.Bank_connect;


public class Bank_connect_test 
{
	private String str_date;
	private String end_date;
	private String curren;
	private Bank_connect bank_c;
	private String[][] out={{"2018-01-03","1,5339"},{"2018-01-02","1,5413"},{null,null}};
	private InputStream in ;
	
	 @Before
		public  void setUp() throws IOException 
	{	 str_date="2018-01-01";
		 end_date="2018-01-02";
		 curren="EUD";
		 String li="https://www.lb.lt/lt/currency/exportlist/?csv=1&currency=AUD&ff=1&class=Eu&type=day&date_from_day=2018-01-01&date_to_day=2018-01-03";
		 URL link = new URL(li);     
	     in = new BufferedInputStream(link.openStream());
		 bank_c=new Bank_connect();
		 
	}

	@Test
	public void test_get_url() 
	{	Assert.assertEquals("https://www.lb.lt/lt/currency/exportlist/?csv=1&currency=EUD&ff=1&class=Eu&type=day&date_from_day=2018-01-01&date_to_day=2018-01-02",bank_c.get_url(str_date,end_date,curren));	}	
	
	@Test
	public void test_getStringFromInputStream()
	{	Assert.assertArrayEquals(out,bank_c.getStringFromInputStream(in));	}
	
}
