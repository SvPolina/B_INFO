package test_classes;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;
import EIS.Data_trans;



public class Data_trans_test {
	
	private String[][] table_text={{"1,541","2018-01-0"},{null,null}};	
	private Data_trans data_t;
	private String e="vvvvvv\n";
    private String a="a;";
    private String b="s;";
    private String c="1,5413;";	
    private String d="2018-01-02;";
    private String raw=e+"\""+a+"\""+b+"\""+c+"\""+d+"\"";
    
    private String[][] to_flip={{"A","B"}};
	private String[][] fliped={{"B","A"}};
	
	
    
	
	@Before
	public  void setUp() 
	{data_t=new Data_trans();}

	@Test
	public void text_to_table_test() 
	{Assert.assertArrayEquals(table_text,data_t.text_to_table(raw));}
	
	
	@Test
	public void flip_columns_test() 
	{ Assert.assertArrayEquals(fliped,data_t.flip_columns(to_flip));}
}
